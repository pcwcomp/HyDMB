# SHARED AMIGA/LINUX PARTITION INSIDE 0x76

**IMPORTANT:** This procedure is meant to be used in a system, in a µSD card with both Musashi and Emu68 installed on it, as described [here](Musashi-and-Emu68-on-the-same-µSD,-booting-from-the-same-drive).

Index: 
* [Compiling and installing AFFS LKM](#Compiling-and-installing-AFFS-LKM)
* [Setting up the shared partition](#Setting-up-the-shared-partition)
* [Setting up Linux Scripts](#Setting-up-Linux-Scripts)
* [Setting up Amiga Scripts and icons](#Setting-up-Amiga-Scripts-and-icons)

The goal of this guide is to setup a _virtual_ Amiga partition (an Amiga partition inside a _physical_ 0x76 partition in the µSD card) that can be "shared" between Amiga and Linux, and the scripts in both sides to control the process.

**>>>> READ CAREFULLY BEFORE PROCEEDING <<<<**

The advantage of using this method over shared folder is speed when transferring data from side to side: shared folder can be very useful for small files or not much data, but is very slow for big amounts of data, and you have to transfer first to the shared folder via wifi and then transfer to a "normal" Amiga drive, because using the data directly from there is impractical due to slowness; the advantage over transferring data over the net directly to the Amiga is, again, speed: 600KB/s using an Amiga TCP/IP stack (MiamiDX) vs. 2.6-3.8MB/s over wifi via SFTP client on Linux to the shared partition.

First of all, the most important one: **"caveat emptor", or "do it at your own risk"**. This has worked for me, but it could not work for you, it could destroy your microSD card, set your A500 on fire, kill your pets, make your house explode……… Whatever happens, it's up to you, not me. As an advice, if you are not sure, do it in a copy of your SD card, or use a new one with a clean install.

Also, I assume you have a working Pistorm/Amiga installation, the knowledge to deal with editing configuration files and so on, as well as some experience using an Amiga. If you are not sure, ask for help or simply don't do what follows.

### Things to take into account:

First one, some procedures take time. Not too much, but be patient and let them finish.

Second one, the shared partition can be mounted only in one side at a time, or weird thing can happen, like writing a file in one side that does not appear in the other one. That will be accomplished with scripts in boths sides, but controlled from the Amiga side.

Third one, it will be used the `pi` command in the Amiga side. The `pi` command allows you to issue commands to the Linux side, for example, `pi ls` will list in the CLI the files in the active Linux folder (usually /pistorm, where the emulator was executed). The problem is that the `pi` command does not processes well Linux `sudo` command when used in scripts, and it is needed, so what we will do is to use scripts in the Amiga side to call scripts in the Linux side, scripts that will execute those needed `sudo` commands.


Let's go…

## Compiling and installing AFFS LKM

**Note:** If you already did this procedure when [setting up a shared HDF](Creating-and-using-a-shared-HDF), you can skip it and jump to [Setting up the shared partition](#Setting-up-the-shared-partition)

1. First, bringing Linux distro up-to-date (upgrade takes some time):

        sudo apt-get update
        sudo apt-get upgrade

2. Then, installing necessary packages:

        sudo apt-get install rpi-source

3. Reboot the RPi:

        sudo reboot

4. Install RPi Linux sources (again, be patient with this one):

        rpi-source

5. Now let's edit Makefile file:

        cd linux/fs/affs
        nano Makefile

6. Comment out following line, by typing a `#` at the start:

        #obj-$(CONFIG_AFFS_FS) += affs.o

    And add this line just below it:

        obj-m += affs.o

    Save and close with Ctrl+S, then Ctrl+X .

7. Now, let's compile the Loadable Kernel Module:

        make -C /lib/modules/$(uname -r)/build M=$(pwd)

8. Once done, let's start it:

        sudo insmod affs.ko

    And check it's installed:

        lsmod | grep affs

    If everything went well, that command should output:

        affs                   49152  0

9. But it will dissapear on next reboot, so let's make it resident:

        sudo cp affs.ko /lib/modules/$(uname -r)/

    Edit this file:

        sudo nano /etc/modules

    Type this as the new last line:

        affs

    Save and close with Ctrl+S, then Ctrl+X . Then:

        sudo depmod -a
        modprobe affs

10. Once again, let's restart the RPi:

        sudo reboot

11. And, once again, let's check the AFFS module is active after the reboot:

        lsmod | grep affs

    If everything went well, that command should output:

        affs                   49152  0


## Setting up the shared partition

**VERY IMPORTANT:** Linux AFFS module only understands FastFileSystem partitions, and it only accepts partitions with blocksize equal or lower to 2048, so be sure to check if the partition you want to share meets the requirements. And if it doesn't and you have any data in it, back it up before changing filesystem or blocksize, doing any of this changes will render your partition unreadable, you will have to reformat it.

12. In the Linux side, first we need to know the name of the physical partition:

        sudo fdisk -l

    This will display a window similar to this one:

    > <img src="https://user-images.githubusercontent.com/88294421/205422010-8966c53d-8f0d-4a1f-a582-ea18bd6d401b.jpeg" width=50% height=50%>

    At the bottom it shows the partitions of the µSD card. The line we are interested in is the one with ID 76, in this case the third one. We need the Device description

        /dev/mmcblk0p3

    Now let's get the numbers we need for the Linux `mount` command:

        sudo parted /dev/mmcblk0p3

    This opens `parted`, the utility for manipulating partition tables. A prompt appears, (parted). Type:

        u b

    and Enter

        p

    and Enter

    The 0x76 partition data will be displayed, showing its inner, _virtual_ Amiga partitions:

        Partition Table: amiga
        
        Number  Start        End           Size         File system  Name  Flags
         1      1032192B     2147475455B   2146443264B               DH0   boot
         2      2147475456B  6441910271B   4294434816B               DH1
         3      6441910272B  16385015807B  9943105536B  affs3        DH2
 

    We need the data from the partition we want to share, in this case DH2. The data we need is its Start, `6441910272`, and its Size, `9943105536`, so save them for later.

    Type:

        quit

    and Enter

13. Then create a mountpoint folder:

        mkdir /home/pi/dh2

14. Now we have the necessary data to mount the partition on Linux, which would be something like this, setting figures of `offset` (=Start figure) and `sizelimit` (=Size figure) with those we saved for later (watch out: WITHOUT the last letter it has in the table, only numbers):

        sudo mount -t affs -o offset=6441910272,sizelimit=9943105536,setuid=1000,setgid=1000 /dev/mmcblk0p3 /home/pi/dh2

    If you want to list its contents:

        ls /home/pi/dh2

    To dismount it, it would be:

        sudo umount /home/pi/dh2


    You can also use the scripts that will be created below. Anyway, in normal conditions everything will be controlled from the Amiga side.


## Setting up Linux Scripts
Now, the Linux scripts:

We will need three scripts, one for mounting, one for dismounting and one for checking if DH2 is mounted on the Linux side, and if yes then dismount it. Why the last one? Imagine that you are using the Amiga, you mount the partition in the Linux side and then you reset the Amiga, or it reboots, whatever the reason. As it reboots, it will mount the partition in the Amiga side by default, and it is already mounted in the Linux side, and that's no desirable, so a check will be added to prevent this.

15. For mounting:

        nano /home/pi/mount_dh2.sh

    then type (again, replacing <s1> and <sz1> figures with those in the previous table):

        #! /bin/bash
        cd /home/pi
        sudo mount -t affs -o offset=6441910272,sizelimit=9943105536,setuid=1000,setgid=1000 /dev/mmcblk0p3 /home/pi/dh2

    Save and close with Ctrl+S, then Ctrl+X

    Then:

        chmod +x /home/pi/mount_dh2.sh


16. For dismounting:

        nano /home/pi/dismount_dh2.sh

    then type:

        #! /bin/bash
        cd /home/pi
        sudo umount /home/pi/dh2

    Save and close with Ctrl+S, then Ctrl+X . Then:

        chmod +x /home/pi/dismount_dh2.sh

17. For checking & dismounting:

        nano /home/pi/check_dh2.sh

    then type:

        #! /bin/bash
        cd /home/pi
        mountpoint -q /home/pi/dh2 && sudo umount /home/pi/dh2

    Save and close with Ctrl+S, then Ctrl+X . Then:

        chmod +x /home/pi/check_dh2.sh


## Setting up Amiga Scripts and icons
Now, the Amiga scripts…

Boot into Amiga and with EditPad/TextEdit or any other text editor you like (Ed, Memacs, CygnusEd, GoldEd, etc.) you will have to create and save three scripts, all three in directory S: .

18. First one dismounts Amiga partition DH2:, mounted by default at boot, and mounts the partition on the Linux side. Type the following text in the editor:

        ;BEGIN Dismounting shared partition in Amiga, mounting in Linux
        failat 21
        version brcm-sdhc.device >nil:
        if fail
            assign dh2: dismount
            pi /home/pi/mount_dh2.sh
            echo "DH2: dismounted"
            wait 1
        else
            echo "Musashi not running"
            wait 1
        endif
        ;END

    Save it in S: with the name DH2Dismount , then type in CLI:

        protect s:DH2Dismount +s

19. Second one dismounts Linux volume and mounts Amiga partition DH2. Type the following text in the editor (see IMPORTANT NOTE below):

        ;BEGIN Dismounting shared partition in Linux, mounting in Amiga
        failat 21
        version brcm-sdhc.device >nil:
        if fail
            pi /home/pi/dismount_dh2.sh
            mounter d=pi-scsi.device u=5 dh2 quiet
            echo "DH2: mounted"
            wait 1
        else
            echo "Musashi not running"
            wait 1
        endif
        ;END

    Save it in S: with the name DH2Mount , then type in CLI:

        protect s:DH2Mount +s

> **IMPORTANT NOTE**: you can see I've used the Amiga command "mounter" for mounting the device in the Amiga side, but it has been distributed with the OS only from v3.5 onwards (3.5, 3.9, 3.1.4 and 3.2). For versions previous to v3.5, you can use SCSIMounter:
>
> https://aminet.net/disk/misc/SCSIMounter203.lha
>      
> Download it, decompress it and copy it preferably to a folder that it's in the path (check this with command `path` from a CLI in Amiga). Usually, Sys:Tools folder will do, but if it is not in te path or simply you are not sure, put it in C:
> Also, its name is "SCSIMounter" and the name of the original command is "mounter", so you either change the name of the file from "SCSIMounter" to "Mounter" or you change the script, replacing "mounter" by "scsimounter". Syntax of both commands is the same.
>      
> Regarding WB 1.3, well, I don't know of a single tool with the same functions of Mounter/SCSIMounter for 1.3 (SCSIMounter needs 2.x or newer), the only option would be to create a mountlist for DH2.

20. Third one checks if Linux volume is mounted and if yes dismounts it. Type the following text in the editor:

        ;BEGIN Check if shared partition is mounted in Linux and dismount it
        failat 21
        version brcm-sdhc.device >nil:
        if fail
            echo "Checking/Dismounting..."
            pi /home/pi/check_dh2.sh
            echo "Done."
            wait 1
        else
            echo "Musashi not running"
            wait 1
        endif
        
        ;END

    Save it in S: with the name DH2Check , then:

        protect s:DH2Check +s

    As you probably noticed, all Amiga scripts, in order to prevent problems, do check if Musashi is running by checking a component that is present only in Emu68.

21. Now, you have to add icons to that files. You can do it, for example, with DirOpus, selecting those files and using its AddIcon function. Another option is open the boot partition, the one with the WB, select in the menu "Window/Show all files", go into the "S" folder, select all three files you just saved and and select menu "Icon/Snapshot", that will create an icon for each one of the selected files.

22. Then, open each icon (select it and then either "LeftAmiga + I", or menu "Icons > Information… "), the icon info window opens. Go to the "Icon" tab and replace the default tool from "SYS:Tools/TextEdit" (or whatever it is, depending on WB version) to "C:IconX". In Tool Types add:

        WINDOW=CON:100/100/250/40//AUTO/NOWAIT/CLOSE

    and Save. Do that for all three icons.

    You can invoke those scripts from the CLI or you can select their icons and select menu option "Icons > Leave Out" to put them in the Workbench, and have them at hand.

    IMPORTANT!: last script, DH2Check, must be placed in WBStartup, so it gets executed at every boot, just to be sure that the shared partition is not mounted in the Linux side. In WBv1.3 (it has no WBStartup) you will have to add the line in the DH2Check script that starts with "pi…" at the end of the s:user-startup file (you can do that also in >=v2.x systems, if you prefer that way)

That's all.

From now on, you will be able, using the Amiga scripts, to dismount one Amiga partition, DH2 in this case, from Amiga and mount it in Linux, and back, instantly, so you can share big amounts of data with ease.

Smol tip: if you don't want, for whatever reason, the shared partition to be mounted on either side, double-click in DH2Dismount icon, then in the DH2Check one, that will dismount it in both sides.

Thanks to Alberto "Lince" (@ea4gge in the networks) for the tip "for Linux everything is a file", that helped me to understand how Linux works when it comes to mounts and shares.

Saluditos,

Ferrán.
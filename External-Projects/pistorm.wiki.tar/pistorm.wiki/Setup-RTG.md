# Instructions for setting up PiStorm RTG
Things you need:
* Picasso96 driver from Aminet or P96 driver from iComp.de
* Updated PiStorm install with the PiStorm utility HDF

### Getting the driver
For the Aminet shareware driver go to [here to get Picasso96.lha](http://aminet.net/package/driver/video/Picasso96)  
For the iComp.de driver go to [here (you must be registered and logged in)](https://icomp.de/shop-icomp/en/shop/product/p96-rtg-software.html) and pay what you want (€8.96 minimum)

### Update PiStorm
Make sure you have a recent build installed from the main branch.
make sure the emulator isn't running. If you set it up as a service as per [boot-scripts](https://github.com/captain-amygdala/pistorm/tree/main/boot_scripts) then you need to stop the service:  
`sudo systemctl stop pistorm`

Then make sure you have the latest stable version  

    cd ~/pistorm
    git pull --ff-only 

**NOTE:** if you have made any changes to any original files (default.cfg, A314 config or saved any changes to the pistorm drive) then the pull will not work. you must backup your configs then force a pull:

    git reset --hard

Then restore your changes, preferably into a copy of the new default.cfg and with a different filename.

Build the new version (if there were changes)

    make clean
    make

And update the bitstream if necessary:

    ./flash.sh

### Copy the driver onto your HDF
Use your preferred method for copying the picasso96.lha (or installation files from iComp.de) to your disk image. One way is to mount your disk image in UAE and use a shared folder to copy the file across.  
The archive needs extracting.  
Dopus is one way - using lha x (if setup)  
![dopus](https://user-images.githubusercontent.com/1519975/127338364-93240c23-7da4-4c7e-8a1d-e03db6503078.jpg)

or in a cli window with lha setup in the path, navigate to wherever the .lha file is placed and type:  

    lha x picasso96.lha
To extract it into the current folder.

The ouput should look something like this:  
![picasso install Files](https://user-images.githubusercontent.com/1519975/127339590-17e6e41f-0590-4cbc-8238-993c0aa41b9b.jpg)

Jens from iComp recommends not installing under emulation so if you are using WinUAE to transfer files, now would be a good time to switch over the real Amiga.

## Installing RTG
Before running the PiStorm emulator, check your config has the following settings uncommented with `nano <name_of_your_config_file>.cfg`

    setvar rtg
and

    setvar piscsi6 platforms/amiga/pistorm.hdf

![config](https://user-images.githubusercontent.com/1519975/127343988-f33189c4-f9e2-4aae-9e2b-d54deea68a04.jpg)

Now let the emulator run either by restarting the service `sudo systemctl start pistorm`  
or by launching the emulator directly `sudo ./emulator --config your_config_file.cfg`

Once workbench is booted, find the place where you copied the extracted files to and go into the Picasso96Install folder and launch the Setup application.

For all prompts Click `Proceed` or `Proceed with Install` except for the prompt for selecting a Graphics card.  
![008](https://user-images.githubusercontent.com/1519975/127356401-1fc07712-8bd1-44f3-a8eb-6a4778fec21a.png)  
You should be able to select no cards and still proceed with the install.  
However if after this prompt:  
![009](https://user-images.githubusercontent.com/1519975/127357004-970ed244-4fea-439e-8e33-67c7e9e81df9.png)  
the installer aborts, then select a card such as Picasso IV  

Continue with the install by selecting the default locations (e.g. SYS:Libs etc) until you are prompted for the P96_PrinterPatch:  
![017](https://user-images.githubusercontent.com/1519975/127358217-3149e47b-d00d-46dc-9576-a9886a8ae7d6.png)  
Select No  

Continue to select `Yes` or `Proceed`, or `Proceed with copy` until the installation is complete.

Now go to the Pistorm utility drive and Launch `rtg -> PiGFX Install -> PiGFX Installer`   
![Pigfx Installer location](https://user-images.githubusercontent.com/1519975/127449562-2f8842c8-aee0-4c59-8861-632dd1de56ff.jpg)  
Again select all the defaults and when prompted find the location of the extracted Picasso96Install folder from previously.  
![Pigfx picasso96install location](https://user-images.githubusercontent.com/1519975/127450026-8117b467-4744-4b31-a1b8-8a31b6a61a3c.jpg)  
Click Proceed through to the end of the installer.

### Setup RTG
Go to **Workbench -> Prefs** and open Picasso96Mode  
![Picasso96 mode](https://user-images.githubusercontent.com/1519975/127452607-364017e7-3c7c-4d28-a5f8-23d2dfdfb5f7.jpg)  
Then Select **Pistorm RTG (1) PiGFX** and scroll down and click Save (it may be off the bottom of the screen but it will scroll)  
You will be prompted to reboot, so let it.

Once you have rebooted, go back into **Workbench -> Prefs** and open **Screenmode**  
Select the mode you want (try 1280x720 and HiColor first) and click Save.  
The Pi will now switch it's HDMI output to display workbench so make sure you have a monitor attached and switch to it (If the Pi was booted without a monitor attached it may default to the composite out. You'll need to [change some HDMI settings in config.txt](https://raspberrypi.stackexchange.com/a/2171) to prevent that)

### You're done!
Sit back and enjoy a cold drink with your new RTG enabled workbench!


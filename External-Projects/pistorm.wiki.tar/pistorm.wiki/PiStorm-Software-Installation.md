# PiStorm Software Installation (Ferry's guide)  

Index: 
* [Raspberry Pi OS installation](#Raspberry-Pi-OS-installation)
* [Installation of PiStorm software](#Installation-of-PiStorm-software)
* [Auto-starting PiStorm emulator](#Auto-starting-PiStorm-emulator)
* [Customizing Features](#Customizing-Features)
* [Advanced Features](#advanced-features-rtg-a314-and-networking)
    - [A314](#A314)
    - [RTG](#RTG)
    - [Networking](#Networking)
* [Sources](#Sources)


### **IMPORTANT NOTE: This guide is made for the BUSTER version of the Rapsberry Pi OS. The necessary options for the BULSSEYE version will be included shortly.**

I will not cover here how to physically assemble the PiStorm and the Raspberry Pi A+, although it should be pretty straightforward: in a A500, take out the CPU, put the PiSorm in its place (pins for the RPi on the left side, close to the left end of the computer) and connect the RPi on it (no possibility -well, smol…- of connecting it wrong).

Instead, I will try to compile all the info scattered over several places in one single document on how to install the software. The info has been took from respective GitHub places, FAQ at Discord, PiStorm disk, etc., so thanks to the respective authors, i.e., Claude, Bnu, LinuxJedi, ChaosPif, Mcgurk and many others.

MY ADVICE: read FIRST the document, then go ahead with the installation.

Let's go:
## Raspberry Pi OS installation
1. Download Raspberry Pi OS from https://www.raspberrypi.org/software/operating-systems/, the Lite version is recommended (less overhead and resources spent on the RPi/linux side, more available for 68k emulation and other Amiga services.
2. Write the Image to a SD Card. You can use the util done exactly for that by Raspberry Pi, their "Raspberry Pi Imager" (available here https://www.raspberrypi.org/software/), it can even download the selected RPi OS, or you can download by yourself and use the util to write it to the SD card. The util can be used too to write any other image you need. You will need for the image at least 8GB, but I'm sure you will want to copy over it several HDF files with AmigaOS, programs, games and other stuff, so I'd recommend a bigger one (16, 32GB).

    **>>IMPORTANT<<**: A recent update of the Raspberry Pi Imager includes a hidden menu where you can enter the data to connect to the WiFi network, the locale to use, the keyboard language, etc.

    The menu appears by pressing Ctrl+Shift+X.

    The following options should be activated and set:

    - Enable "Set hostname", preferably leaving the default name, "raspberrypi.local".
    - Enable "Enable SSH". When you do this, the "Use password authentication" option is enabled by default, where you will set the password for the user "pi".
    - Activate "Configure wifi". Enter the name of the SSID and its password, and the corresponding "Wifi country" country code (f.ex., "GB" for Great Britain, according to the ISO 3166-1 alpha-2 codes, at https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2 ).
    - Activate "Set locale settings". Set the corresponding time zone according to your place (f.ex., for UK, "Europe/London") and the keyboard keys distribution (default, American , "us"). As an option, and if you have already set all the data with these options, you can activate "Skip first-run wizard".

    If you use this menu, you can skip steps 7, 9 and 10 in this guide, you will only need the RPi configuration utility to define the display mode (step 8).
3. Connect an HDMI Display and a USB keyboard to the PiStorm. Using a USB Hub is possible, an externally powered hub is recommended. Connect the Amiga to the PSU and PAL Monitor
4. Insert the SD into the Raspberry Pi, Power on the Amiga now. You should see a Rainbow colored screen on the HDMI Monitor and the PiStorm booting. When the boot process is finished (on the first run it reboots automatically after resizing the filesystems to your SD) you should be greeted with the login prompt.
5. Log in as the default user, typically user: pi and password: raspberry. (The keyboard is set to US Layout on first boot!)
6. Run:  

    	sudo raspi-config

7. Set up your preferences like keyboard layout, language, etc. (in section "5 Localisation Options"). Beware when selecting Locale, selection must be done with space bar, not Enter.
8. It is recommended to set the screen resolution (section "2 Display Options") to 1280x720.  
    I myself am using a Dell monitor wwith several inputs and PictureByPicture mode, that shows RPi and Amiga screens side by side, and the proportion of each one is more a 4:3 than anything else, so I'm setting RPi resolution, for testing purposes, to 800x600 mode, it's a 4:3 mode, similar to those used in Amiga (PAL:Hires Laced), and later, using RTG, I can choose it and get it without scaling: setting one mode for RPi and then another RTG one for the Amiga will result in a scaled window inside the RPi screen, only same screen resolution or multiple of the RPi one will fill the screen completely.
9. Set up your Wi-Fi credentials (in section "1 System Options")
10. Enable SSH at boot time (in section "3 Interface Options")
11. Exit raspi-config  
    You can now reach the PiStorm over SSH, check your router web/settings page to find the IP of the PiStorm, or run

	    ifconfig

    locally on the PiStorm from the console (wlan0: entry, second line after it, when it says inet and then the IP of the RPi on the LAN).  
    The command to reach the RPi from another computer is, from a terminal:

        ssh <ip> -l pi

    substituting <ip> with RPi IP number, being "pi" the user, or also with

        ssh pi@raspberrypi.local

    It will ask you for the password, default one is "raspberry", same as in system login.  
    Another advantage of activating SSH, besides being able to access remotely, is that you also have FTP access to copy files into the microSD, with a client that supports SFTP (Filezilla, Cyberduck, Pete's FTP, WinSCP…)

## Installation of PiStorm software
12. Now the final steps to get things up and running, all of this is done from a command prompt (terminal) either locally on the PiStorm or over ssh, typing:

        sudo apt-get update
        sudo apt-get install git libsdl2-dev
        git clone https://github.com/captain-amygdala/pistorm.git pistorm
        cd pistorm
        make

    That will compile the emulator, you can run it straight away but ONLY if you have programmed the PiStorm CPLD first. If not, you need to do this:
13. Install OpenOCD:

        sudo apt-get install openocd

    Run the CPLD update:

        ./flash.sh

    You can also try an experimental firmware with some improvements, but do it at your own risk, it could not work for you:

        ./flash_experimental.sh

    If no fatal error messages are printed on screen and everything went well, you'll see a message saying that the CPLD has been programmed successfully.  
    For upgrading to an updated firmware, just run the same command again
14. You can check if your PiStorm is working properly running the following test: (with the Pi and PiStorm physically in your Amiga)

        chmod +x ./build_buptest.sh
        ./build_buptest.sh
        sudo ./buptest

    Buptest puts random data into the physical RAM on the amiga and reads it back to check for errors.
15. If software at the GitHub page has been updated, you can update locally with the following commands (you have to be in the pistorm directory):

        git pull --ff-only
        make clean
        make

    **BEWARE: if you have modified any original files like default.cfg, doing "git pull" won't work.** You will have to force the pull which will delete your modified files so back them up them to a safe place. A better idea is to use a copy of default.cfg and use that with emulator.

    cp default.cfg myconfig.cfg

    To force a `git pull` use:

        git reset --hard
        git pull --ff-only
        make clean
        make

16. You can now start the PiStorm emulator with a basic config by typing (again, you have to be in the pistorm directory)

        sudo ./emulator

    and hitting enter. You can also specify a custom config file by typing

        sudo ./emulator --config-file myconfig.cfg

    To exit the emulator you can press Ctrl+C on the instance you started, be it the keyboard connected to the RPi or the SSH session, or typing in any SSH session:

        sudo pkill emulator 

    With nothing else installed, you will see the Kickstart screen of the physical ROM installed on the A500. You can load diskettes, either original ones or from a Gotek, the Amiga should work as it originally did with the 68000 CPU.

## Auto-starting PiStorm emulator
17. If you want to start the emulator as part of the RPi booting process, first create the pistorm.service file with the following command:

        sudo nano /etc/systemd/system/pistorm.service

    and write this text in it:

        [Unit]
        Description=PiStorm emulator
        After=network.target
        StartLimitIntervalSec=0
        [Service]
        Type=simple
        Restart=always
        RestartSec=1
        User=root
        ExecStart=/home/pi/pistorm/emulator
        WorkingDirectory=/home/pi/pistorm
        [Install]
        WantedBy=multi-user.target

    If you want to run emulator from a custom config file (i.e., myconfig.cfg), change the line

        ExecStart=/home/pi/pistorm/emulator

    for

        ExecStart=/home/pi/pistorm/emulator --config-file myconfig.cfg

    Once done, press Ctrl-X, then Y, then Enter. Then, type the following command to enable the service:

        sudo systemctl enable pistorm.service

    To reload services and activate it:

        sudo systemctl daemon-reload

    Now every time you switch on the Amiga, the RPi will directly load the emulator, so the Amiga will start.


18. As stated before, if you started the emulation by hand, you can stop it by pressing Ctrl-C in the keyboard connected to the RPi, or, whatever the method used to start it, from a SSH terminal connected to the RPi by typing:

        sudo pkill emulator

    If you installed emulator as a service, you can stop it with:

        sudo systemctl stop pistorm.service

    You can even disable the service with:

        sudo systemctl disable pistorm.service

    If you do so, you will have to start it by hand with:

        sudo systemctl start pistorm.service

    Once the proper software has been installed in the Amiga, you will also be able to do it from a CLI or even from the "Execute command…" WB menu option (it can be invoked by pressing RightAmiga+E), usign the `pi`command.

## Customizing Features

Now, let's start copying some Amiga stuff to make the Amiga start with something more than a KS boot screen.

19. Using the SFTP client from another computer, you can copy a ROM file for the emulator to load it. Even if it's the same you have, it will load faster than the original, physical one.
    My recomendation is to copy it outside the "pistorm" directory, in /home/pi, so it will be not affected by git updates. BTW, you can also use the SFPT client to move files betwewen folders in the very RPi, or rename, delete them, etc.
    For the emulator to use it, you will need to change one line in the config file. This can be done by typing in RPi terminal (you have to be in the pistorm directory):

        nano default.cfg

    A text editor will show you the config file for you to edit it. I'll assume you have named your ROM file "kick.rom". Look for the line

        #map type=rom address=0xF80000 size=0x80000 file=kick.rom ovl=0 id=kickstart

    and uncomment it (delete the # character in the first position). If you copied the "kick.rom" file to the pistorm directory, it's ok that way,

        map type=rom address=0xF80000 size=0x80000 file=kick.rom ovl=0 id=kickstart

    If you copied to the /home/pi directory, then you must make a small modification to the "file=kick.rom" part, to indicate that the ROM file is in the upper directory:

        map type=rom address=0xF80000 size=0x80000 file=../kick.rom ovl=0 id=kickstart

    You can save it by pressing Ctrl-X, then Y, then Enter. There are more options to be modified but first you'll need an HDF (a Hard Disk File) to install a system and boot from.
20. You can use a ready-made HDF, there are several of them, but be careful: if you use one created with WinUAE or FS-UAE, it has to be one created with RDB (Rigid Disk Block), without it it won't work. If you want to try it, copy it over SSH with a SFTP client to your location of choice.

    You can also create a blank HDF file from the RPi itself, with the command:

        fallocate -l 2016M amiga.hdf

    It will create a 2016MB HDF in the directory you are now. Again, I'd recommend to create it in the /home/pi directory, so files will not be affected with updates. You can modify the value after "-l" to make a larger/smaller HDF, but preferably multiple of 504MB (504M, 1008M, 2016M, 4032M…)

    The reason for this recommendation is that HDF access is FASTER when the HDToolBox "disc" has 16 heads, and the 504MB-multiple sizes make HDToolBox automatically "detect" that number of heads. If you choose any other size, but want that extra speed, you can edit the disc definition in HDToolBox to manually enter those 16 heads.
21. Whatever the choice, you will need to modify the default.cfg file again. You have to be in the pistorm directory (or wherever the config file is located):

        nano default.cfg

    Locate and uncomment (delete the #) the following lines

        #setvar piscsi
        #setvar piscsi0 PI0.hdf

    Then, in the second line, change "PI0.hdf" for the name given to the HDF you copied over or the one you created (amiga.hdf). Lines should look like this:

        setvar piscsi
        setvar piscsi0 amiga.hdf

    Take advantage of the fact you are editing the config file to activate other functions that you will need later. Locate this lines and uncomment them, by deleting the # :

        #setvar rtg
        #setvar a314_conf ./a314/files_pi/a314d.conf
        #setvar a314

    Again, save the file pressing Ctrl-X, then Y, then Enter.

**IMPORTANT NOTE: autoboot from a HD or HDF will work only from KS 2.x or newer**, it's a limitation of the KickStart version, not the PiStorm.

22. If you chose the ready-made hdf, the system should boot as it did in UAE. You can go directly to step nr. 24.
    If you made a blank HDF, you will need to partition it. In order to do this, you'll need a system disk with HDToolBox, and you'll have to replace the SCSI_DEVICE_NAME in its icon from scsi.device to pi-scsi.device, so it can recognize the HDF as a hard disk.
23. Once partitioned, install a system from diskettes or Gotek.
# Advanced Features (A314, RTG and Networking)
## A314
24. Once the system is installed and you have booted from it, you'll see a disk called "PiStorm", put there by the emulator/config file, with all the files you'll need for A314 emulation, network and RTG.
    First of all, let's copy all necessary files to the Amiga installation. Open a CLI window by pressing RightAmiga+E, then type newcli , then Enter. In the CLI, for the A314 emulation type:

        copy dh99:a314/a314.device devs:
        copy dh99:a314/a314fs l:
        type dh99:a314/a314fs-mountlist >> DEVS:Mountlist
        copy dh99:a314/pi c:

    With the files you just copied you can now (almost) control the RPi from the Amiga, with the "pi" command you gain access to the Linux console. Type:

        pi

    This will log you into RPi Linux shell (you'll see in the CLI the Linux shell prompt). From here you can, for example, shutdown the emulation by typing

        sudo pkill emulator

    or reboot the RPi by typing

        reboot

    or even shut it down by typing

        poweroff

    You can issue those commands in one single line, as arguments of the "pi" command:

        pi sudo pkill emulator
        pi reboot
        pi poweroff

    and you can do it from the CLI or even from the "Execute command…" WB menu option.  
    Of course, you will be able to do many other things that Linux allows you to do.

    To go back from Linux prompt to Amiga prompt, type

        exit
25. Also, you will have a shared folder in the RPi side that you will be able to access from the Amiga side, by typing in CLI or "Execute command…" window

        mount PI0:

    you will see a "PiDIsk" icon appearing in the WB. In the Linux side, the shared folder is located in /home/pi/pistorm/data/a314-shared

    This is very handy to tranfer files to the Amiga side: you can copy files there with the SFTP client from another computer to the RPi and them read those files from the Amiga side. Only one small drawdack: it's a bit slow, so I' d recommend to use it to copy files to the Amiga HDF and work with them from there, not the PI0: unit.
26. In the "PiStorm" disk there are two tools that allow you to do interact with the Amiga, the PiStorm and the RPi. One is a CLI command called "PiSimple", these are its usage and functions:

        1.WBv3.2:> pisimple 
        Usage: pisimple --[command] (arguments)
        Example: pisimple --restart, --reboot or --reset
               Restarts the Amiga.
               pisimple --check, --find or --info
               Finds the PiStorm device and prints some data.

    and the GUI tool "PiStorm", which allows you to change the ROM you want to boot with, have the emulator use a different configuration file, reboot or shutdowm the RPi, etc.

    To copy those tools to the Amiga, type in the CLI:

        copy dh99:PiStorm#? sys:tools
        copy dh99:PiSimple c:

    "PiStorm" tool needs "reqtools.library", there are two versions in the disk, for AmigaOS v 1.3:

        copy dh99:libs13/reqtools.library libs:

    or for AmigaOS v2.0 or higher:

        copy dh99:libs20/reqtools.library libs:

27. For the network service (it will need more configuration and file copying later):

        copy dh99:a314/a314eth.device devs:

## RTG  
(There is also a graphical walkthrough at [Setup RTG](Setup-RTG) although it assumes you already have lha and DOpus installed)  

28. For the RTG, you will need first to download two files from Aminet. You have two options: do it in another computer and copy via SFTP those files to the shared folder, the download links are:  
    https://aminet.net/util/arc/lha.run  
    https://aminet.net/driver/video/Picasso96.lha

    Remember that the shared folder is, by default, in /home/pi/pistorm/data/a314-shared.

    Or do it directly from the RPi (if emulation is running, you can do it from a SSH shell connected to the RPi) with wget command:

        wget https://aminet.net/util/arc/lha.run -P /home/pi/pistorm/data/a314-shared
        wget https://aminet.net/driver/video/Picasso96.lha -P /home/pi/pistorm/data/a314-shared

    Then, let's copy those files into the Amiga HDF. We'll make a "Downloads" drawer in the HDF for downloaded stuff. In the CLI type:

        makedir sys:downloads

    Copy archives just downloaded:

        copy PI0:lha.run sys:downloads
        copy PI0:Picasso96.lha sys:downloads

    Then, decompress LhA archive to RAM: so you can copy the correct file to c:

        sys:downloads/lha.run -x ram:

    If you are using the default configuration (CPU set to 68020) or CPU set to 68030:

        copy ram:lha_68020 c:lha

    If you are using CPU set to 68040:

        copy ram:lha_68040 c:lha

    That one will let you uncompress the next one. Copy also its documentation, just in case:

        copy ram:LhA.guide c:

    and clean RAM: from remaining files:

        delete ram:lha#?		

    Now, decompress Picasso96 to RAM:

        lha x sys:downloads/Picasso96.lha ram:

    In RAM:, a drawer called "Picasso96 Install" will be created. Go there from WB, install Picasso96 by double-clicking in the "Setup" icon and follow instructions. When asked to choose a graphic card, you can choose whatever you want, it will not be used.

    After installation, don't delete this folder in RAM:, next step will need it. If a reboot is required, after rebooting type again last line in CLI to decompress Picasso96.lha to RAM:.

    Go to the "PiStorm" disk in WB, open it and find a drawer called "rtg", open it, you'll see a icon, "PiGFX Install". Double click on it to install, follow instructions. You will have to tell it where the Picasso96 installation drawer is, it's the one you decompressed in RAM:. Once done, you can either reboot the Amiga typing in CLI (or pressing Ctrl+A+A: yes, it works)

        pisimple --restart

    or go in WB to Devs:Monitors drawer and double-click in the "PiGFX" icon to activate RTG screenmodes. If you open in WB Screenmode preferences,   you'll see all the new RTG screenmodes.

## Networking
29. You need to stop emulation, if running, and issue the following commands in the Linux shell:

    Install the pip3 command:

        sudo apt install python3-pip

    Install python-pytun

        sudo pip3 install python-pytun

    Copy the tap0 to /etc/network/interfaces.d/:

        sudo cp /home/pi/pistorm/a314/files_pi/eth-config-pi/tap0 /etc/network/interfaces.d/

    Add NAT rules to forward the requests from the amiga into the wi-fi:

        sudo iptables -t nat -A POSTROUTING -o wlan0 -j MASQUERADE
        sudo iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
        sudo iptables -A FORWARD -o tap0 -m state --state RELATED,ESTABLISHED -j ACCEPT  
        sudo iptables -A FORWARD -i tap0 -j ACCEPT

    Make the NAT rules persistent:

        sudo apt install iptables-persistent

    Agree to the IPv4 question, you can pick any answer for IPv6

    Enable IPv4 forwarding by editing /etc/sysctl.conf with:

        sudo nano /etc/sysctl.conf

    Uncomment the line, by removing the #:

        net.ipv4.ip_forward=1

    Save the file pressing Ctrl-X, then Y, then Enter.

    Reboot the Pi with

        sudo reboot
30. For the Amiga part you need a TCP/IP stack. There are at least two documented options for working TCP/IP stacks, "Roadshow" and "AmiTCP". The first one is commercial, although there's a demo that will shutdown after 15 minutes. The full version costs $25. The second one is freely available in Aminet. The main difference between both is that while the first one is being mantained, bugfixed, etc. (last version is from Sept 2020), the second one's last version is from 2012.

    For installing "Roadshow", download the demo from here (for "AmiTCP", go to step nr. 31):
    https://www.amigafuture.de/app.php/dlext/details?df_id=3657

    and copy it via SFTP to the shared folder. From here, copy it to the Amiga HDF and decompress it to RAM:, by typing in the CLI:

        copy PI0:Roadshow-Demo-1.14-2020-09-05.lha sys:Downloads/
        lha x sys:Downloads/Roadshow-Demo-1.14-2020-09-05.lha ram:

    From the WB, go to the RAM: disk, open "Roadshow-Demo" drawer and double-click in "Install_Roadshow" to install it.  
    If you are using the full version, process should be pretty much the same, but changing the names for those of the full version.  
    Once installed, copy the following files from the "PiStorm" disk, by typing in the CLI:

        copy dh99:a314/eth-config-amiga/A314Eth DEVS:NetInterfaces/
        copy dh99:a314/eth-config-amiga/routes DEVS:Internet/
        copy dh99:a314/eth-config-amiga/name_resolution DEVS:Internet/

    Reboot the Amiga typing in CLI (or pressing Ctrl+A+A)

        pisimple --restart

    Now you should already have Roadshow-based network connection in your Amiga. Check if everything worked typing in CLI:

        ping www.google.com

31. If you prefer to try "AmiTCP", follow these steps:  
    Download it from Aminet in another computer and copy it to the shared folder via SFTP. The link is:  
    https://aminet.net/package/comm/net/AmiTCP-bin-30b2.lha

    Or do it directly from the RPi (if emulation is running, you can do it from a SSH shell connected to the RPi) with wget command:

        wget https://aminet.net/package/comm/net/AmiTCP-bin-30b2.lha -P /home/pi/pistorm/data/a314-shared

    Then copy it to the Amiga HDF and decompress it to RAM: disk:

        copy dh99:AmiTCP-bin-30b2.lha sys:Downloads
        lha x sys:Downloads/AmiTCP-bin-30b2.lha ram:

    Then go from WB to RAM: disk, open it, open "AmiTCP-3.0b2" folder, then find and double-click on "Install_AmiTCP" icon to install it and follow these steps:  	
    - Intermediate User -> Proceed With Install
    - Install for Real, Log None -> Proceed
    - Select directory where to install: Work:AmiTCP-3.0b2 -> Proceed
    - Confirm the copy -> Skip This Part (do 4 times)
    - Do you want to install example Sana-II configuration files? -> Yes
    - Select Sana-II configuration files to be copied: -> Proceed with Copy
    - Do you want to install Napsaterm fonts -> Yes
    - Select directory where to install Napsaterm fonts: fonts: -> Proceed
    - Logging in as 'root'... -> Proceed
    - Give empty password and close login window
    - Enter default user name: user -> Proceed
    - Enter the host name of your computer: amiga -> Proceed
    - Enter domain part of your host name: local -> Proceed
    - The host name "amiga.local" will be stored... -> Store to ENV(ARC):
    - Give aliases... (leave empty) -> Proceed
    - Select a SANA-II device driver: -> Parent Drawer -> a314eth.device -> Proceed
    - Select unit number: 0 -> Proceed
    - IP address: 192.168.2.2 -> Proceed
    - Give destination address... (leave empty) -> Proceed
    - Netmask of network on interface: 255.255.255.0 -> Proceed
    - Is this correct? -> Yes
    - Select a SANA-II device driver: (leave empty) -> Proceed
    - Enter the IP address of the default gateway: 192.168.2.1 -> Proceed
    - Give domain names: (leave default) -> Proceed
    - Give domain names: (leave empty) -> Proceed
    - Give the IP addresses of the name servers: 1.1.1.1 -> Proceed
    - Give the IP addresses of the name servers: 1.0.0.1 -> Proceed
    - Give the IP addresses of the name servers: (leave empty) -> Proceed
    - Do you want the AmiTCP/IP to be started at the system startup? -> Yes
    - Do you want Installer to make the rquired chages to yout s:user-startup script? -> Yes
    - Do you want the Inetd to be started at the AmiTCP/IP startup -> Yes
    - Quit readme with q-key.
    - Installation complete! -> Proceed

    Once finished with installation, type in CLI:

        ed s:user-startup

    That will open the file s:user-startup in the default Amiga text editor. Then  
    - Find (cursor on it) and delete login-line by pressing ESC, then D, then Enter
    - Save file and exit by pressing ESC, then x, then Enter

    Edit the "interfaces" file:

        ed Work:AmiTCP-3.0b2/db/interfaces

    - Add line: eth dev=devs:a314eth.device
    - Save file and exit by pressing ESC, then x, then Enter

    Edit the "startnet" file:

        ed Work:AmiTCP-3.0b2/bin/startnet

    - modify ifconfig-lines to look like this:

        AmiTCP:bin/ifconfig lo0 localhost
        AmiTCP:bin/ifconfig eth0 192.168.2.2 netmask 255.255.255.0

    - Save file and exit by pressing ESC, then x, then Enter

    Make sure that startnet executable bit is set by typing in the CLI:

        protect Work:AmiTCP-3.0b2/bin/startnet +s

    Reboot the Amiga typing in CLI (or pressing Ctrl+A+A)

        pisimple --restart

    Now you should already have AmiTCP-based network connection in your Amiga. Check if everything worked typing in CLI:

        ping www.google.com

Well, by now you should already have your PiStorm/RPi-powered Amiga up un running at full steam with all available services on.

Just one more thing: there's a far easier alternative to all this, and it's to find a distro, that is, an image of an SD card with a working Linux, with all software already installed and everything working, and write it to an SD card with the Raspberry Pi Imager, Etcher or any other method. In one simple sentence, someone made the work for you (and got the fun of doing it).

I know Spanish RetroWiki forum made one for the custom PiStorm they did for their users, just go there and ask => http://retrowiki.es/portal

Also, you can find customs distros in the #custom-distros chat at the PiStorm Discord channel ( https://discord.com/invite/j6rPtzxaNW ), it's the official PiStorm developing channel. There you will find not only those distros (if any), but a lot of nice and experienced people willing to help and doing great things.

I myself prefer the "hard" but funny way of doing it step by step, that's how one learns.

## Sources

https://github.com/captain-amygdala/pistorm

https://github.com/beeanyew/pistorm/tree/wip-crap

https://linuxjedi.co.uk/2021/04/15/lightning-amiga-performance-with-pistorm/

https://github.com/captain-amygdala/pistorm/tree/main/a314

https://github.com/captain-amygdala/pistorm/tree/main/platforms/amiga/piscsi

https://github.com/captain-amygdala/pistorm/tree/main/boot_scripts

I'm sure I'm forgetting some other sources, but, as you can see almost all the info comes from original Claude's branch (now made as the Bnu's wip-crap one), the Bnu's wip-crap branch and from the Discord channel, I just gathered, compiled it and tried to put it in a single file. If you want more advanced features/options, you can go there and read.

I hope this has been helpful.

Saluditos,

Ferrán.

**WARNING**: while it is true that having an existing shared drive can be very convenient, you also have to take into account that YOU ARE MOUNTING THE LINUX LOADING PARTITION: if you screw up anything, you better have a copy at hand, because if you delete what you shouldn't, you may not be able to load from that card anymore, i.e. neither Linux nor Musashi nor Emu68 (if you have it all on the same card).  

Again, as in the past: "caveat emptor", or "do it at your own risk". This has worked for me, but it might not work for you, it might destroy your microSD card, set your A500 on fire, kill your pets, cause your house to explode.......... Whatever happens, it's up to you, not me.

Let's get down to it:

From Linux

`sudo fdisk -l`

This will display a window similar to this one:

> <img src="https://user-images.githubusercontent.com/88294421/205422010-8966c53d-8f0d-4a1f-a582-ea18bd6d401b.jpeg" width=50% height=50%>

At the bottom it shows the partitions of the µSD card. The line we are interested in is the first one, which, in a standard RPi OS installation, is FAT32. Also, it is marked as "Type: W95 FAT32", so there is no error.

We need the Device description

`/dev/mmcblk0p1`

and the value of Sectors, in this case

  `8822784`

First, with Musashi off, we edit the Musashi configuration file (by default, Amiga.cfg), with which we will define the path for Musashi to access, using the Device description from before:
 
`setvar piscsi1 /dev/mmcblk0p1` 

 The number of the variable "piscsi" can be any number between 0 and 5 that is not already occupied (6 is reserved for the disk with PiStorm software, although it could also be used if the disk is deactivated). Save the configuration file with the changes and restart Musashi.

Switch to the Amiga part and create a mountlist similar to this one (can't be done with GiggleDisk, it doesn't see anything on that drive):  

    /* fat95 file system by Torsten Jager */
    
    FileSystem     = l:fat95
    Device         = brcm-sdhc.device
    Unit           = 0
    Flags          = 0
    LowCyl         = 8192
    HighCyl        = 8830976
    Surfaces       = 1
    BlocksPerTrack = 1
    BlockSize      = 512
    Buffers        = 300
    BufMemType     = 1
    BootPri        = 0
    Stacksize      = 4096
    Priority       = 5
    GlobVec        = -1
    DosType        = 0x46415401
    Flags          = 0x101 /* Reserved */


Substitute the value of Device

`brcm-sdhc.device`

by

`pi-scsi.device`

We set Unit to the value we have used in the variable "piscsi#" in the Musashi configuration file, in this case 1.

In the value of LowCyl we put `0`.

In the value of HighCyl we put the Sectors value of fdisk that we reserved at the beginning, in this case, `8822784`.

We save the mountlist with the name we want (in my case, SD1), and mount it, e.g. from CLI, with

`mount SD1:`

There you should see the "boot" drive icon appear on the WB:

> <img src="https://user-images.githubusercontent.com/88294421/205422299-f45817b5-c8cd-47a0-add6-815aa04b3bba.jpeg" width=50% height=50%>

I tried to create a directory ("Amiga Stuff") in that drive with DOpus, and copy some data inside (several files from my Downloads folder), to see if they could be seen from Linux. Result: SUCCESS, they look good and can be read, unzipped, etc..:

> <img src="https://user-images.githubusercontent.com/88294421/205422373-ba908e7e-dc87-4438-a3e0-8321b5ea3d9d.jpeg" width=100% height=100%>

**IMPORTANT (again):**

Again, given the "delicate" nature of that partition, be careful. Also, I cannot foresee the side effects of the drive being mounted on both operating systems at the same time, how that might affect the operation of the system, both Linux and Amiga. As I have already warned, it is your responsibility to be careful with what you do, to have backups, etc. For example, I would say that it is not a bad idea, if you are going to use it regularly, to create a directory for moving data between other systems and Amiga, and, as a precaution, not to leave it.

And I would say that's all.  

My thanks to @katazakis for the challenge, for asking if that would be possible at all. I mean, it was his idea ;) 

Saluditos,

Ferrán.





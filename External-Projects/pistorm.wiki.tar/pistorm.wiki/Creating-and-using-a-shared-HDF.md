# SHARED AMIGA/LINUX HDF

### **IMPORTANT NOTE: This guide is made for the BUSTER version of the Rapsberry Pi OS. The necessary options for the BULSSEYE version will be included shortly.**

Index: 
* [Compiling and installing AFFS LKM](#Compiling-and-installing-AFFS-LKM)
* [Setting up and partitioning the shared HDF](#Setting-up-and-partitioning-the-shared-HDF)
* [Setting up Linux Scripts](#Setting-up-Linux-Scripts)
* [Setting up Amiga Scripts and icons](#Setting-up-Amiga-Scripts-and-icons)

The goal of this guide is to setup a HDF file that can be "shared" between Amiga and Linux, and the scripts in both sides to control the process.

**>>>> READ CAREFULLY BEFORE PROCEEDING <<<<**

The advantage of using this method over shared folder is speed when transferring data from side to side: shared folder can be very useful for small files or not much data, but is very slow for big amounts of data, and you have to transfer first to the shared folder via wifi and then transfer to a "normal" Amiga drive, because using the data directly from there is impractical due to slowness; the advantage over transferring data over the net directly to the Amiga is, again, speed: 600KB/s using an Amiga TCP/IP stack (MiamiDX) vs. 2.6-3.8MB/s over wifi via SFTP client on Linux to the shared HDF.

First of all, the most important one: **"caveat emptor", or "do it at your own risk"**. This has worked for me, but it could not work for you, it could destroy your microSD card, set your A500 on fire, kill your pets, make your house explode……… Whatever happens, it's up to you, not me. As an advice, if you are not sure, do it in a copy of your SD card, or use a new one with a clean install.

Also, I assume you have a working Pistorm/Amiga installation, the knowledge to deal with editing configuration files and so on, as well as some experience using an Amiga. If you are not sure, ask for help or simply don't do what follows.

### Things to take into account:

First one, some procedures take time. Not too much, but be patient and let them finish.

Second one, the HDF can be mounted only in one side at a time, or weird thing can happen, like writing a file in one side that does not appear in the other one. That will be accomplished with scripts in boths sides, but controlled from the Amiga side.

Third one, it will be used the `pi` command in the Amiga side. The `pi` command allows you to issue commands to the Linux side, for example, `pi ls` will list in the CLI the files in the active Linux folder (usually /pistorm, where the emulator was executed). The problem is that the `pi` command does not processes well Linux `sudo` command when used in scripts, and it is needed, so what we will do is to use scripts in the Amiga side to call scripts in the Linux side, scripts that will execute those needed `sudo` commands.


Let's go…

## Compiling and installing AFFS LKM
1. First, bringing Linux distro up-to-date (upgrade takes some time):

        sudo apt-get update
        sudo apt-get upgrade

2. Then, installing necessary packages:

        sudo apt-get install rpi-source

3. Reboot the RPi:

        sudo reboot

4. Install RPi Linux sources (again, be patient with this one):

        rpi-source

5. Now let's edit Makefile file:

        cd linux/fs/affs
        nano Makefile

6. Comment out following line, by typing a `#` at the start:

        #obj-$(CONFIG_AFFS_FS) += affs.o

    And add this line just below it:

        obj-m += affs.o

    Save and close with Ctrl+S, then Ctrl+X .

7. Now, let's compile the Loadable Kernel Module:

        make -C /lib/modules/$(uname -r)/build M=$(pwd)

8. Once done, let's start it:

        sudo insmod affs.ko

    And check it's installed:

        lsmod | grep affs

    If everything went well, that command should output:

        affs                   49152  0

9. But it will dissapear on next reboot, so let's make it resident:

        sudo cp affs.ko /lib/modules/$(uname -r)/

    Edit this file:

        sudo nano /etc/modules

    Type this as the new last line:

        affs

    Save and close with Ctrl+S, then Ctrl+X . Then:

        sudo depmod -a
        modprobe affs

10. Once again, let's restart the RPi:

        sudo reboot

11. And, once again, let's check the AFFS module is active after the reboot:

        lsmod | grep affs

    If everything went well, that command should output:

        affs                   49152  0


## Setting up and partitioning the shared HDF
12. If everything went fine and your house didn't explode, you should be seeing your bash prompt and located at your user folder. Let's create a 1GB shared HDF there:

        fallocate -l 1008M /home/pi/shared.hdf

13. Now add this new HDF to the emulator config file, for example:

        setvar piscsi4 /home/pi/shared.hdf

    You can, of course, use another unit number instead of 4 or another name for the HDF, but then be carefull and change them accordingly in all commands that use them.

14. Run the emulator to start the Amiga and partition and format the new "hard disk" with HDToolBox. Remember you MUST use FFS (recommended FFS03, International mode). Also, since it will be a "transfer" HDF, partition it with just one partition, to make things simpler. Name it as you want, I'll use the name "XF0" for reference. Format it (name it as you want). Shut the emulator down.

15. Now, back to the Linux side, let's get the numbers we need for the Linux `mount` command:

        parted /home/pi/shared.hdf

    This opens `parted`, the utility for manipulating partition tables. A prompt appears, (parted). Type:

        u b

    and Enter

        p

    and Enter

    The HDF partition data will be displayed:

        Partition Table: amiga

        Number Start  End   Size   File system    Name  Flags
        1      <s1>   <e1>  <sz1>  affs1          XF0  

    Type:

        quit

    and Enter

16. Then create a mountpoint folder:

        mkdir /home/pi/xf0

17. Now we have the necessary data to mount the HDF on Linux, which would be something like this (replacing <s1> and <sz1> figures with those in the previous table WITHOUT the last letter, only numbers):

        sudo mount -t affs -o offset=<s1>,sizelimit=<sz1>,setuid=1000,setgid=1000 /home/pi/shared.hdf /home/pi/xf0

    If you want to list its contents:

        ls /home/pi/xf0

    To dismount it, it would be:

        sudo umount /home/pi/xf0


    You can also use the scripts that will be created below. Anyway, in normal conditions everything will be controlled from the Amiga side.


## Setting up Linux Scripts
Now, the Linux scripts:

We will need three scripts, one for mounting, one for dismounting and one for checking if XF0 is mounted on the Linux side, and if yes then dismount it. Why the last one? Imagine that you are using the Amiga, you mount the HDF in the Linux side and then you reset the Amiga, or it reboots, whatever the reason. As it reboots, it will mount the HDF in the Amiga side by default, and it is already mounted in the Linux side, and that's no desirable, so a check will be added to prevent this.

18. For mounting:

        nano /home/pi/mount_xf0.sh

    then type (again, replacing <s1> and <sz1> figures with those in the previous table):

        #! /bin/bash
        cd /home/pi
        sudo mount -t affs -o offset=<s1>,sizelimit=<sz1>,setuid=1000,setgid=1000 /home/pi/shared.hdf /home/pi/xf0

    Save and close with Ctrl+S, then Ctrl+X

    Then:

        chmod +x /home/pi/mount_xf0.sh


19. For dismounting:

        nano /home/pi/dismount_xf0.sh

    then type:

        #! /bin/bash
        cd /home/pi
        sudo umount /home/pi/xf0

    Save and close with Ctrl+S, then Ctrl+X . Then:

        chmod +x /home/pi/dismount_xf0.sh

20. For checking & dismounting:

        nano /home/pi/check_xf0.sh

    then type:

        #! /bin/bash
        cd /home/pi
        mountpoint -q /home/pi/xf0 && sudo umount /home/pi/xf0

    Save and close with Ctrl+S, then Ctrl+X . Then:

        chmod +x /home/pi/check_xf0.sh


## Setting up Amiga Scripts and icons
Now, the Amiga scripts…

Boot into Amiga and with EditPad/TextEdit or any other text editor you like (Ed, Memacs, CygnusEd, GoldEd, etc.) you will have to create and save three scripts, all three in directory S: .

21. First one dismounts Amiga partition XF0:, mounted by default at boot, and mounts the HDF on the Linux side. Type the following text in the editor:

        assign xf0: dismount
        pi /home/pi/mount_xf0.sh
        echo "XF0: dismounted"

    Save it in S: with the name DismountXF0 , then type in CLI:

        protect s:DismountXF0 +s

22. Second one dismounts Linux volume and mounts Amiga partition XF0. Type the following text in the editor (see IMPORTANT NOTE below):

        pi /home/pi/dismount_xf0.sh
        mounter d=pi-scsi.device u=4 quiet
        echo "XF0: mounted"

    Save it in S: with the name MountXF0 , then type in CLI:

        protect s:MountXF0 +s

> **IMPORTANT NOTE**: you can see I've used the Amiga command "mounter" for mounting the device in the Amiga side, but it has been distributed with the OS only from v3.5 onwards (3.5, 3.9, 3.1.4 and 3.2). For versions previous to v3.5, you can use SCSIMounter:
>
> https://aminet.net/disk/misc/SCSIMounter203.lha
>      
> Download it, decompress it and copy it preferably to a folder that it's in the path (check this with command `path` from a CLI in Amiga). Usually, Sys:Tools folder will do, but if it is not in te path or simply you are not sure, put it in C:
> Also, its name is "SCSIMounter" and the name of the original command is "mounter", so you either change the name of the file from "SCSIMounter" to "Mounter" or you change the script, replacing "mounter" by "scsimounter". Syntax of both commands is the same.
>      
> Regarding WB 1.3, well, I don't know of a single tool with the same functions of Mounter/SCSIMounter for 1.3 (SCSIMounter needs 2.x or newer), the only option would be to create a mountlist for XF0.

23. Third one checks if Linux volume is mounted and if yes dismounts it. Type the following text in the editor:

        echo "Checking/Dismounting…"
        pi /home/pi/check_xf0.sh
        echo "Done."

    Save it in S: with the name CheckXF0 , then:

        protect s:CheckXF0 +s


24. Now, you have to add icons to that files. You can do it, for example, with DirOpus, selecting those files and using its AddIcon function. Another option is open the boot partition, the one with the WB, select in the menu "Window/Show all files", go into the "S" folder, select all three files you just saved and and select menu "Icon/Snapshot", that will create an icon for each one of the selected files.

25. Then, open each icon (select it and then either "LeftAmiga + I", or menu "Icons > Information… "), the icon info window opens. Go to the "Icon" tab and replace the default tool from "SYS:Tools/TextEdit" (or whatever it is, depending on WB version) to "C:IconX". In Tool Types add:

        WINDOW=CON:100/100/250/40//AUTO/NOWAIT/CLOSE

    and Save. Do that for all three icons.

    You can invoke those scripts from the CLI or you can select their icons and select menu option "Icons > Leave Out" to put them in the Workbench, and have them at hand.

    IMPORTANT!: last script, CheckXF0, must be placed in WBStartup, so it gets executed at every boot, just to be sure that the shared HDF is not mounted in the Linux side. In WBv1.3 (it has no WBStartup) you will have to add the line in the CheckXP0 script that starts with "pi…" at the end of the s:user-startup file (you can do that also in >=v2.x systems, if you prefer that way)

That's all. From now on, you will have at Amiga boot an HDF loaded at start appearing in the Amiga side as XF0:, and you will be able, using the Amiga scripts, to dismount it from Amiga and mount it in Linux, and back, instantly, so you can share big amounts of data with ease.

Smol tip: if you don't want, for whatever reason, the shared HDF to be mounted on either side, double-click in DismountXF0 icon, then in the CheckXF0 one, that will dismount it in both sides.

Of course, this has been a team effort, so acknowledgement should also go to @ea4gge (original idea of sharing a HDF between the two systems, and testing), @DaRaSCo (original method for recompiling kernel, and testing) and @minifrizzle (special thanks to him, he has saved a lot of time to a lot of people by compiling only affs as a LKM -Loaded Kernel Module- ;) , and testing).

Saluditos,

Ferrán.
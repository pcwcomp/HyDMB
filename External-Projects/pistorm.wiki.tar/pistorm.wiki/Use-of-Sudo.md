# Use of Sudo
(originally posted by @linuxJedi at https://linuxjedi.co.uk/2021/07/18/this-week-in-pistorm-2021-07-18/ )

The “sudo” prefix for commands in Linux basically says “run this as a superuser” and it can be extremely tempting to do all the time just so that you don’t hit any problems. Unfortunately the overuse of this is causing problems for some users. So, here is some handy pointers of where you do and do not need to use sudo:

### Do NOT

You should not use sudo when doing:

* git commands
* make commands
* Running the firmware flash commands

If you use “sudo” for any of the above you may end up with files owned by the superuser which cannot be accessed correctly by your user. If this happens you can `cd` into your PiStorm directory and run:
	
    sudo chown -R pi .

This will change the ownership of all files for PiStorm back to the pi user.

### Do

You should run sudo when doing the following:

* apt commands
* Running the `./emulator` directly
* Copying files to `/etc` such as the systemd start script

The emulator (for now) requires superuser access for the GPIO communication. Since `apt` makes system changes this requires roots and `/etc` files are typically superuser owned (or owned by a system user).  
### Optional

You can use sudo for `systemctl [action] pistorm` but this isn’t required. If you execute it without sudo then it will ask for your user password.
## Contents
* [Community](#community)
* [Purchase/Building](#PurchaseBuilding)
* [Setup/Hardware](#setuphardware)
* [Troubleshooting](#troubleshooting)
* [IMPORTANT WARNING](#do-not-run-buptest-while-you-have-the-emulator-running)

## Community  

Q. **Where can I discuss things with you/join the community?**  
A. We are most active on Discord - [Join the server here](https://discord.com/invite/j6rPtzxaNW)  
you can also join our Facebook group if you dislike Discord here https://www.facebook.com/groups/pistorm/  
Follow [Claude on twitter](https://twitter.com/Claude1079)  
If you're Old Skool and want to join the discord discussions via IRC then we have an IRC bridge too:  
On the Libera IRC network (irc.libera.chat):

    - #PiStorm, bridged with the #general channel on Discord
    - #PiStorm-hardware which is bridged with #hardware
    - #PiStorm-firmware, bridged with #firmware
    - #PiStorm-Amiga bridged with #software-amiga
    - #PiStorm-pi, brigded with #software-pi
    - #PiStorm-chat, bridged with #ot-and-chitchat
And also most of the usual amiga formus have discussions about PiStorm now too

## Purchase/Building  

Q. **What are all the different PiStorm variants everyone keeps talking about? PiStorm32? PiStorm600? which one do I need? HALP!**  
A. 
* **PiStorm** - The original. or O.G. sometimes called PiStorm16 or PiStorm DIP. This is the one that everyone knows about and fits into the DIP64 socket of the 68000 CPU replacing it directly. Can be (currently) used in an A500, CDTV(with experimental firmware) A1000, A2000 models by directly replacing the CPU (some relocation or creative case alterations may be required) or in the CPU slot of an A2000 with a CPU slot adapter. **Usable but should still be considered BETA at this time**  
* **PiStorm2K** - A variant of the O.G. which directly plugs into the A2000 CPU slot. **Currently WIP**  
* **PiStorm600** - A variant of the O.G. specifically for A600 with a PLCC CPU clip-on socket. **Currently awaiting compatible firmware**  
* **PiStorm32** - 32-bit PiStorm for 32-bit Amigas starting with A1200 _**VERY VERY**_ **early stage development**  

Q. **There are** ***PICTURES*** **of PiStorm32. Wh3n cAn i haZ 1 aLredy???!!?!**  
A. Those pictures are all that exists of PiStorm32. Claude has literally just had the prototype delivered and (as of September 8th) he's taken a few pictures of it put together and verified he can boot PiOS on the CM4 but that's as far as it's got. There's LOTS of work to do as it's totally different to PiStorm O.G. - Different bus protocol, different FPGA, CM4 has more GPIO available. barely anything from PiStorm OG will be usable.  
You're looking at the earliest of 2022 before we'll be near ready to start putting them into people's hands and even that is a bit optimistic.

Q. **Where can I order a PiStorm?**  
A. ~~Use the pinned form in the #signup channel of discord and you can either start a group buy or join another person's group buy to get a PiStorm for a really good price (dependent on ability to order the CPLD from JLCPCB. At this time the silicon shortage is playing havoc with the ultra cheap group-buys.)~~ Groupbuy has been suspended for the forseeable future. While JLC was able to make fully populated boards with only CPU pins and Pi header needing to be easily soldered on, it was a simple thing to buy them in batches of 10-50 and distribute to the group members. With the explosion in popularity co-inciding with the international chip shortage biting hard, JLC now don't have any of the CPLD's in stock and putting together a group buy batch now takes considerably more time and effort than our willing members are able and/or willing to sacrifice. The fabled £11 price was contingent on the group buyer merely needing to take components from one package and putting them into another to send on to it's recipient. Now with component price rises and build/test time and effort, the group buy builders aren't able to offer them much cheaper than the proliferation of sellers that have appeared for reasonable (and not so reasonable) prices. As the list changes frequently, ask in Discord or Facebook as to where is selling them for sensible money.  

Q. **Where can I find the current files to make my own PiStorm**  
A. Look in the Release Files section of the discord server and currently #pistorm-rev-b channel has a zip containing gerber files, BOM and placement files for submitting to JLCPCB

Q. **How much does a PiStorm cost?**  
A. There is no simple answer Current Chip shortages mean you cannot get them 100% assembled by JLC The SMD fully assembled price should not be much more than around $20USD (local delivery and taxes not withstanding) for the A500 version. But each group buy operator may have their own costs to deal with so please understand variations in pricing. However the CPLD needs to be purchased and fitted seperately now and this introduces much variability into the cost. True group buy 100% assembled cost is around $15 but the hand built nature of the final board means $40 is a more typical price

Q. **How do I order from JLC PCB? I've never ordered PCB's or PCB Assembly before...**  
A. follow this [guide](https://docs.google.com/document/d/1ORX4mLhMJySeeOtXmMbgd80VhJ2JcimCRQQjqB2-QJE/edit?usp=sharing)

Q. **I cant find any of the CPLDs, Where are there EPM570T100C5 that don't have a stupid long lead time**  
A. The 570 seems to be EOL but the EPM240T100 or GT variants (EPM240GT100) of both (I5N, C5N or A5N) are also suitable substitute and the build files specify them in the BOM (by LCSC part number but the reference is still the old part name) - however both are hard to source now, and JLC has neither generally right now. If a GT variant is chosen, the the 1.8v regulator in U9 needs to be specified and the 0 Ohm resistor in R5 needs to be removed.  

Q. **What is available now?**  
A. A PiStorm adapter board for a Pi3A+ to fit in the DIP64 of an A500(+), A1000, A2000 (or in the CPU slot on a riser card) and CDTV. Versions that are Work In Progress are A600, and A2000 CPU slot. 
A1200/3000/4000 versions are future projects at this time. Pi 4 support is coming soon and CM4 adapter boards are also being looked at.

Q. **Can I just buy one from a shop? What's with this whole groupbuy thing?**  
A. PiStorm is an open source project. If you want, you can take the fabrication (gerber) files and get blank PCBs made up from any PCB manufacturer. JLC, PCBWay, DirtyPCBs, OSHpark etc. And order the components from the BOM and solder them up yourself. Claude has also made the production files to have them assembled at JLC PCB so that all the tricky SMD part soldering is taken care of. Compared to typical manufacturing places, getting small (in industrial terms) batches made is incredibly cheap. But still needs quantities of 10 or more to really take advantage as there are some fixed cost overheads per batch. As nobody has as yet taken up the mantle to get a large run made, there are a few stores to buy from, Amiga-Kit, Amigastore.eu and a few ebay sellers have done limited runs of them. but the CPLD shortage is making it hard for everybody right now

Q. **How long is the wait for a group buy PiStorm?**  
A. At this point it's unknown as the major component in the PiStorm build (the CPLD) has gone out of stock due to the semiconductor shortage. if you are not already expecting one to arrive, it may be a considerable wait until the parts are available again. This problem is affecting the entire electronics industry, from GPUs to cars.

Q. **There are different versions of the EPM240 and EPM570 CPLDs available, which ones can I use?**  
A. You can use EPM240T100 or EPM570T100 in either the C5, I5 or A5 variants. Whilst others are available (for example C4, C3, etc) you may have issues going forward as the firmware develops, so while they may work now, they may not in the future. The recommendation is to use one of those mentioned above and you are good to go.  
It has also been confirmed that the GT variant (eg. EPM570GT100C5N, or EPM240GT100C5N) also work. PLEASE NOTE that the GT version requires 1.8v VCC_INT, so to use these on PiStorm you have to populate U9 with an LM1117-1.8 and remove R5.

Q. **The 74LVC16373 is out of stock is there any alternative that can be used?**  
A. The 74LVC16373 is interchangeable with the 74LVC16374 (and A variants of both e.g. 16373A) so you are free to use either. Ideally they need to be the TSSOP package, but the SSOP version has been used, but is an extremely tight fit on the pads.

Q. **The BOM doesn't reference U9, should it be populated?**   
A. No, U9 is not required when using an EPM240T100 or EPM570T100. Stick to the BOM and you are all good.  
If you are using a GT variant (eg. EPM570GT100C5N, or EPM240GT100C5N), then you will need to populate U9 with an LM1117-1.8 and remove R5 to provide the 1.8v that it requires. PLEASE NOTE this is ONLY required for the GT variant and MAX-V (currently unsupported).

Q. **Are schematics available as well as the Gerber files?**  
A. Yes. [Here is the Rev B](https://cdn.discordapp.com/attachments/833686489674154014/840365376168919080/Pistorm_Rev_B-1.pdf).

Q. **There is a short between two pins near C4 on my CPLD, is this an issue?**
![solder bridge](https://media.discordapp.net/attachments/833686489674154014/884058732651225088/Screenshot_2021-09-05-13-49-09-79_572064f74bd5f9fa804b05334aa4f912.jpg)  
A. No as these pins are both connected to ground. The cause is simply that the soldermask separating these pins is extremely thin and some PCB manufacturers seem to have issue with it. The mask is also easily removed while hand soldering.  
If these two pins are shorted, don't worry, all is fine. On the other hand, if any other pins are shorted then that is more of a cause for concern.  

Q. **Is there REALLY a GLOBAL shortage of chips? Isn't it just PS5's, GPUs and other high end stuff?**  
A. Yes there is and not just 3080 GPUs. [Here's a good explainer on the reasons why](https://amp.theguardian.com/technology/2021/may/14/global-shortage-of-computer-chips-could-last-two-years-says-ibm-boss)

Q. **The semiconductor shortage seems to have been going on for months. Surely it's over by now?**  
A. Nope. Just check some tech news sites. They are predicting it to go well into next year and beyond. It's now starting to affect contactless bank cards as well as CPLD's microcontrollers and GPU's. It's literally affecting every industry going.

Q. **But I really really really neeeeeeeeeeeeeeed a PiStorm!**  
A. That's not a question. And No, you don't. it's still VERY beta anyway, with many bugs still to resolve. it's not reliable enough to use as a main amiga accelerator for anything yet. you've been coping fine for 25 years without it, a few more months won't make any difference.

## Setup/Hardware

Q. **I am an ultra n00b with linux and raspberry pi's. And I fear the terminal. Is there an easy to install one-click setup or guide?**  
A. At the moment PiStorm is very early stage development and is far from a finished product, that is in a constant state of flux. If you want to start using it now you should be comfortable with setting up Raspberry pi's, using the command line terminal, connecting via SSH, using git clone and generally be OK with stuff not working as you might expect. If you are not OK with this then maybe wait til the project is a bit more mature. 
Having said that, if you are interested in helping out to achieve making it totally n00b friendly then feel free to pitch in! (like contributions to this wiki)

Q. **I'm having trouble creating working HDFs, WinUAE is just the worst. Are there some premade blank hard drive images I can use?**  
A. Yes! @Lemarux has created these two blanks in RDB format, just under 8gig and 16gig. 
Both have a 500MB partition for your Workbench/AmigaOS, and another partition for the rest of the free space. Both are using PFS3AIO for the filesystems.  
[BlankPFS3-8GB.zip](https://cdn.discordapp.com/attachments/833686489674154014/885582568131543133/BlankPFS3-8GB.zip)  
[BlankPFS3-16GB.zip](https://cdn.discordapp.com/attachments/833686489674154014/885582609487388682/BlankPFS3-16GB.zip)  

Q. **How do I start the PiStorm emulator on boot? How can I make it boot faster?**  
A. There are multiple ways to do this, you can find a guide on the link below which covers how to have PiStorm start before the network connections have been initiated. There are also details on other things you can change to decrease boot times.  
[Boot scripts](https://github.com/captain-amygdala/pistorm/tree/main/boot_scripts)

Q. **How do I update the PiStorm software on my Raspberry Pi?**  
A. Run the following commands from within your PiStorm folder:  

    git pull
    make clean  
    make  
If there have been any changes to the bitstream you will also need to update that by running `./flash.sh` (or `./flash_experimental.sh` for the experimental bitstream) again.  

If using and older PiStorm build that does not have the updated flash commands:  
For EPM570 CPLDs run:  
    `sudo ./nprog.sh`  
For EPM240 CPLDs run:  
    `sudo ./nprog_240.sh`

Q. **Can I use a Pi 2 / 3B / 4 / whatever with PiStorm**  
A. The PiStorm is only compatible with the Pi 3 series, specifically the Pi 3A+. It is not (yet) compatible with the Pi 4 and a Pi 3B will need physical modifications or a taller stacking header block to fit to the board.

Q. **Can I use PiStorm in my Amiga 1200 / 2000 / 600?**  
A1. The current standard DIP64 PiStorm can be used in an A2000 either in the same way it is in an A500 by replacing the 68K CPU chip or with a CPU Slot riser. A dedicated CPU slot version is still WIP.

A2. There is a WIP board for the A600 which is unreleased right now due to the current firmware being incompatible with the A600. once a compatible firmware is released, the A600 board will be available

A3. Amiga 1200 support will come in the form of a 32-bit PiStorm once the 16-bit version is some kind of stable. at this time it is an idea with no actual work having started on it yet although prototype PCB's have been made.

Q. **How do I enable and use RTG?**  
A. Please see the instructions [here](setup-rtg)

Q. **How do I enable and use the PiSCSI interface?**  
A. Please see the instructions [here](https://github.com/captain-amygdala/pistorm/tree/main/platforms/amiga/piscsi)  

Q. **How can I shutdown the Pi before the Amiga to avoid corruption of the SD card?**  
A. The risk of corruption of the SD card is extremely low. In the hundreds of times the developers of PiStorm have power cycled Amigas we have not observed a corruption due to this. It is recommended (as with all Amigas in general) that you wait until any disk access is completed before powering down the Amiga. It is also highly recommended that you take backups of anything valuable on your SD card such as HDF images. This is also because SD cards are not SSDs, they do not have the relocation, self-repair and wear-levelling features of SSDs and are much more susceptible to hardware failure. All that being said are CLI and GUI tools made for the Amiga which is in a small HDF mounted by default in the current main branch which contains a few useful utilities. The Pistorm interaction tool (simply "Pistorm" in the Pistorm HDF image) will allow you to perform a number of tasks including a "safe shutdown" of the pi before you power off. Essentially analagous to having to "park" hard drive heads before powering them off BITD.

Q. **Can I use a Pi Zero with a PiStorm?**  
A. Not currently but in the WIP PROTO4 firmware there is experimental compatibility now with any Pi with a 40 pin header to work. Including a zero. Though it only makes it slightly faster than a stock A500+/A600. ![speeeeeeed demon](https://cdn.discordapp.com/attachments/800296283378155560/839194474638868540/PXL_20210504_173811624.jpg)

Q. **Is there a spare GPIO pin to initiate a shutdown?**  
A. No the whole GPIO band is in use getting 68k data to and from the amiga. And see above about shutting the pi down.

Q. **Are you sure? Really really really sure?**  
A. Yes

Q. **What about the camera port? I read that there's unused GPIO there?**  
A. No. There are plans to use the CSI2 port to pass native RGB data from Denise to have a single HDMI that handles both RTG modes and native Denise modes as a passthrough.

Q: **Is there a "stock 68000 CPU mode" planned for the PiStorm to increase compatibility/run something at proper speed/etc?**  
A: No, there is not. This does not mean that someone can't add something like that, but no one currently working on the project has their sights set on anything like this.  
In the case of an Amiga, if you require stock 68000 operation and speed, you are better off putting the 68000 back in for now. While maprom and some other features do work when using 68000 emulation, many of the advanced things like PiSCSI and the RTG require a 32-bit CPU to work properly, and these would not be available unless someone adapted them to work on a CPU with a 24-bit address bus.

## Troubleshooting  

Q. **Sysbench is showing < 20x the speed of an A600, I think it should be faster, what gives?**  
A. Check your power supply. If the 5V rail drops too low the Pi intentionally underclocks itself significantly to stay stable. Setting 'force-turbo' entry in /boot/config.txt may improve things, and there may be evil fire breathing dragons doing this.

Q. **What diagnostics can I run to test PiStorm?**  
A. After flashing the CPLD, compile buptest in the pistorm folder by the following commands:  

    chmod +x ./build_buptest.sh  
    ./build_buptest.sh  
    sudo ./buptest  
 Buptest puts random data into the physical RAM on the amiga so must be run when fully assembled  

------------------------------------------------------
DO NOT RUN BUPTEST WHILE YOU HAVE THE EMULATOR RUNNING 
------------------------------------------------------

Q: **[Game/Demo/Application] that I've tried does not work properly, music is too fast, game runs too slow, what's up?**  
A: At this time, there are issues with the interrupts, and chipset/Chip RAM bandwidth is slightly lower (sometimes)than with a regular 68000 CPU due to CPLD bus translation, these issues are being worked on to be fixed in a later firmware update.

Q: **Should I install the MMUlibs for use with the AmigaOS install on my PiStorm?**  
A: No. The Musashi MMU emulation is not complete, or completely accurate. Adding MMU emulation to the mix only slows things down, and can cause problems that are difficult to diagnose.

Q: **I'm getting vertical screen tearing and bits of windows / icons are left behind. How can I fix this?**  
A: This appears to be an issue with fblit that comes with some ClassicWB installs, please try disabling this.

Q: **What is "wip-crap", and how do I use it?**  
A: "wip-crap" is the name of beeanyew's pistorm branch where many of the latest bleeding edge WIP features are being worked on and tested, it is specifically this: https://github.com/beeanyew/pistorm/tree/wip-crap  
To use wip-crap, you have to do the following:  
    `git clone https://github.com/beeanyew/pistorm.git` (or `git clone https://github.com/beeanyew/pistorm.git wipcrap` to clone it to a directory named wipcrap instead of pistorm.)
Then follow these steps:  
`cd pistorm` (or `cd wipcrap`, if you cloned it to a wipcrap directory)  
`git checkout wip-crap` <- **This step is very important. Without it, you won't be using the wip-crap branch**.  
`make`  
To update to the latest commit of the branch at any time, use  

    git pull
    make  
again.  
If the emulator doesn't appear to be working properly after running make, proceed to do make clean and then make and wait for the compilation to finish, then run it again. If it's still not working, there's probably some issue that will be resolved soon.

Q. **Where can I find the latest CPLD firmware?**  
A. The latest firmware can always be [found here in this repo](https://github.com/captain-amygdala/pistorm). Any other bitstreams that you see posted on discord are purely experimental and are only meant for testing purposes. They are NOT recommended for general use, unless advised to do so. From the main repo, after you have confirmed you have the latest from git ( `git pull --ff-only` ) if there were changes reported to anything in the `nprog` folder, then there may have been a change to the firmware. use `./flash.sh` to flash the regular firmware and `./flash_experimental.sh` to flash the experimental firmware to your CPLD.(Experimental firmware sometimes has tweaks for systems that don't work too well with the regular firmware, like CDTV)

Q. **BUPTEST is showing me garbege mismatch errors and I can't find any solder problems on the PiStorm. What else can I do?**  
A. Re-seat all the chips in the Amiga and make sure the Amiga is working without the PiStorm in first. PiStorm won't fix a broken Amiga (unless it's a broken CPU.)  
If you still can't track down the problem you may need to troubleshoot each data and address pin with breadboard and LED's to highlight where the errors might be. @abrugsch has a ready made tester board which is exactly that, an LED on every I/O line on the CPU socket. [it can be found here](https://github.com/abrugsch/pistormTester) along with tester code to run after assembling it

Q. **I inserted my Pi into the header wrong. Did I break something or how can I test it?**  
A. GPIO pins frequently get damaged from mis-connections as they are only rated for 3.3v. Fortunately they can be tested.  
**This MUST be run disconnected from the PiStorm**  
Just power up the Pi with USB and do it outside the Amiga entirely.  
Info from https://www.raspberrypi.org/forums/viewtopic.php?t=180505

relevant commands:  

    sudo apt-get install pigpio  
    wget abyz.me.uk/rpi/pigpio/code/gpiotest.zip  
    unzip gpiotest.zip  
    sudo pigpiod  
    ./gpiotest
However, the bad news is that if it shows any of the GPIO's as having failed, then they are un-recoverable as they are internal to the main SoC (System on Chip) so the Pi must be relegated to a life that doesn't involve GPIO (or at least the broken ones) like as a Kodi, RetroPie or PiHole device.

Q. **My PiStorm programmed fine using nprog or flash scripts, so it is good, right?**  
A. Programming the CPLD only tests that the CPLD powers up and the 4 JTAG pins work. So ~6 of its 100 pins are actually soldered correctly. Relatively speaking you probably only tested that 1% of the whole board works. Please see how to use "buptest" above as a next step.

Q. **I bought a PiStorm with a MAX-V chip and it doesn't flash successfully. How do I get it working?**  
A1. You don't*. Return it to the seller for a refund. MAX-V is not supported (yet... see A2) and may not be for a considerable time for a variety of reasons. See this week in PiStorm for the full details https://linuxjedi.co.uk/2021/07/11/this-week-in-pistorm-2021-07-11/  

A2. If you like to live dangerously, there is now a VERY BETA firmware but it significantly overclocks the CPLD and runs it out of spec  BY A LOT. functionality will be very dependent on silicon lottery if the sepcific chip you have can cope with the added speed. visit discord #beta-testing-maxv for bleeding edge details

Q. **Can I use an HDF from my NAS?**  
A. Yes! although it will probably be as slow as a real amiga unless you have a very high performance NAS and network infrastructure.  
First, you need to set up a mount point for your NAS share location. There are plenty of guides on how to do this by searching for `mount cifs share linux` in your search engine of preference and there are a few different ways, either by fstab: https://linuxize.com/post/how-to-mount-cifs-windows-share-on-linux/ or via a mount service: https://michlstechblog.info/blog/systemd-mount-examples-for-cifs-shares/  
Once you have the NAS folder mounted into the linux file system you can simply add the path of your hdf into the PiStorm config file as such:  
`setvar piscsi0 /mnt/mynas/amigafolder/workbench31.hdf`

Q. **Everything has gone wierd and nothing works anymore. I've done a make clean and a make but emulator won't boot like it used to. What can I do?**  
A. One step to take on the troubleshooting road is to backup any config files, HDF's etc. and do a complete ground up clean of the PiStorm folder as sometimes there can be some crufty object files lurking if you've been through many `make clean` cycles. i.e:  
`rm -rf pistorm/` <-- this will delete everything in the folder and remove it without blinking so make sure you type it right!
followed by  
`git clone https://github.com/captain-amygdala/pistorm.git`
then  
`cd pistorm`  
`make`  
and just test the emulator starts with the default config
`sudo ./emulator`  
Then start rebuilding your config from your backup.
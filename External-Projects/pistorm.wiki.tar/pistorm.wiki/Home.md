Welcome to the PiStorm wiki!  

Ferry's master "Install all the things" [document from discord](PiStorm-Software-Installation)

Check out the [FAQ's](FAQs)

Find the walkthrough for setting up [RTG here](setup-rtg)

The guide for setting up an HDF that can be shared between both the amiga side and Linux side is [here](Creating-and-using-a-shared-HDF)  

You don't need (or should) use sudo all the time. Read [Use of Sudo](use-of-sudo) to see exactly when to and not to use it.

[How to install](Musashi-and-Emu68-on-the-same-µSD,-booting-from-the-same-drive) Musashi and Emu68 on the same µSD, booting from the same drive

[How to mount](How-to-mount-FAT32-partition-from-Musashi) FAT32 partition from Musashi

[Sharing an Emu68 partition](Sharing-in-Linux-a-'virtual'-Amiga-partition-(inside-0x76-one)-from-Musashi) in Linux from Musashi
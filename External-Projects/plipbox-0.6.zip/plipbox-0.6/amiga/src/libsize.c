#include <stdio.h>
#include "global.h"

int main(int argc, char **argv)
{
   printf("libsize equ %d\n", sizeof(struct PLIPBase));
   return 0;
}
